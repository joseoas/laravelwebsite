<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/cover.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontawesome/css/font-awesome.min.css')); ?>">

    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>

        <!-- End Styles -->
    </head>
    <body>

        <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top " >
                <div class="container">
                      <a class="navbar-brand" href="#">
                      <img src="<?php echo e(asset('images/logo.png')); ?>" height="40px" width="65px">cotizaisaprechile
                      </a>

                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav mr-auto">
                          <li class="nav-item active">
                            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#">Quienes somos</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#">Nuestros Servicio</a>
                          </li>

                            <li class="nav-item">
                            <a class="nav-link" href="#">Contacto</a>
                          </li>                                                   
                        </ul>
                        
                            <a class="nav-link" href="#" ><img src="<?php echo e(asset('images/facebook.png')); ?>"></a>
                            <a class="nav-link" href="#" ><img src="<?php echo e(asset('images/youtube.png')); ?>"></a>
                        </div>

                      </div>
                </div>
             </nav>

    <div class="site-wrapper">

          <div class="site-wrapper-inner">

          <div class="container marin">
              
              <?php echo $__env->yieldContent('content'); ?>

          </div>

        </div>
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

    </body>
</html>
