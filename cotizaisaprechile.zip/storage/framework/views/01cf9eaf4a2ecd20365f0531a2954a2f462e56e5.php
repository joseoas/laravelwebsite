<?php $__env->startSection('content'); ?>
			<div class="row">
				<div class="col-md-12">
					       <div class="text-left "><h4> <i class="fa fa-address-card color_icon" aria-hidden="true"></i>  Vendedores </h4></div><br>

							<div class="card ">
									<div class="card-header">
										<div class="row">
											<div class="col-md-10 text-left">
												 Vendedores Registrados : <div class="badge badge-danger"><?php echo e($count); ?></div>
											</div>
											<div class="col-md-2 text-right">
												<a class="btn btn-success" href="<?php echo e(route('sellers.add')); ?>"> <i class="fa fa-plus" aria-hidden="true"></i> Nuevo Vendedor</a>
											</div>
										</div>
									</div>       
										<table class="table table-hover text-left ">
										  <thead >
										    <tr>
										      <th>#</th>
										      <th>Rut</th>
										      <th>Nombre</th>
										      <th>E-Mail</th>
										      <th>Isapre</th>
										      <th>Accion</th>
										    </tr>
										  </thead>
										  <tbody>

										    <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    	    <tr>
												      <th scope="row"><?php echo e($key); ?></th>
												      <td><?php echo e($seller->rut_seller); ?></td>
												      <td><?php echo e($seller->name_seller." ".$seller->lastname_seller); ?></td>
												      <td><?php echo e($seller->email_seller); ?></td>
												      <td><?php echo e($seller->name_isapre); ?></td>

												      	<td>
												      		<div class="row">
												      			<div class="col-md-4 text-lefet">
												      				<a href="<?php echo e(route('sellers.edit',$seller->id)); ?>"	class="btn btn-info">
												      					<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar
												      				</a>
												      			</div>

												      			<div class="col-md-8 text-left">
												      				<form action="<?php echo e(route('sellers.destroy',$seller->id)); ?>" method="POST">
															      		<?php echo e(csrf_field()); ?>

															      		<?php echo e(method_field('DELETE')); ?>

															      		<button class="btn btn-danger" type="submit"><i class="fa fa-eraser" aria-hidden="true"></i> Eliminar</button>
												      				</form>
												      			</div>

												      		</div>												
												      	</td>
											      	</tr>
										    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										  </tbody>
									</table>
								</div> 

				</div><!--  FIN COL 7-->
				

			</div>

    <?php echo e($sellers->links()); ?>

		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbackend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>