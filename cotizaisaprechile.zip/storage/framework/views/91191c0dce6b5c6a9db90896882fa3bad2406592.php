<?php $__env->startSection('content'); ?>

	<div class="text-left">  <i class="fa fa-address-card color_icon" aria-hidden="true"></i> Nuevo Vendedor</div>
	<br>
	<div class="card text-left">
		<div class="card-header"> Vendedor</div>
		<div class="card-body">
			<form action="<?php echo e((isset($seller)) ?  route('sellers.update',$seller->id) :  route('sellers.input')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

					<div class="form-group text-left">
						<div class="row">
							<div class="col-md-4">
								<label>Rut</label>
								<input type="text" class="form-control" name="rut" value="<?php echo e(isset($seller) ? $seller->rut_seller : ''); ?>">
							</div>
							<div class="col-md-4">
								<label>Nombres</label>
								<input type="text"  class="form-control" name="nombre" value="<?php echo e(isset($seller) ? $seller->name_seller : ''); ?>">
							</div>
							<div class="col-md-4">
								<label>Apellidos</label>
								<input type="text"  class="form-control" name="apellido" value=" <?php echo e(isset($seller) ? $seller->lastname_seller : ''); ?>">
							</div>
						</div><!--FIN ROW-->
					</div><!--FIN FORM-FROUP-->
					<div class="form-group text-left">
							<div class="row">
								<div class="col-md-6">
									<label>Telefono Celular</label>
									<input type="text" class="form-control" name="movil" value="<?php echo e(isset($seller) ? $seller->smartphone_seller : ''); ?>">
								</div>
								<div class="col-md-6">
									<label>Telefono Red Fija</label>
									<input type="text" class="form-control" name="fijo" value="<?php echo e(isset($seller) ? $seller->phone_seller : ''); ?>">
								</div>
							</div><!--FIN ROW2-->
					</div><!--FIN ROW-->
					<div class="form-group text-left">
							<div class="row">
								<div class="col-md-6">
									<label>Email</label>
									<input type="text" class="form-control" name="email" value="<?php echo e(isset($seller) ? $seller->email_seller : ''); ?>">
								</div>
								<div class="col-md-6">
									<label>Isapre</label>

										<select class="form-control" name="isapre">
											<?php $__currentLoopData = $isapres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isapre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($isapre->id); ?>" <?php echo e(($seller->id_isapre==$isapre->id) ? 'selected' : ''); ?> ><?php echo e($isapre->name_isapre); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
							

								</div>
							</div><!--FIN ROW3-->
					</div><!--FIN ROW-->

					<div class="form-group">	
						<div class="row">
							<div class="col-md-6">
								<button class="btn btn-success"> <i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
							</div> 
							<div class="col-md-6"></div>
						</div><!--FIN ROW4-->
					</div><!--FIN FORM-GROUP-->	
			</form>
		</div><!--FIN CARD BODY-->	
	</div><!--FIN CARD-->


		<?php if($errors->any()): ?>
		    <div class=" text-left">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appbackend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>