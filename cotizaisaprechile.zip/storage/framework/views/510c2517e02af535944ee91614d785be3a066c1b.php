<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/cover.css')); ?>">
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>

        <!-- End Styles -->
    </head>
    <body>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
             <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="container">
            <a class="navbar-brand" href="#">
             <img src="<?php echo e(asset('images/logo.png')); ?>" width="80" height="50"> Cotiza Isapre Chile
            </a>

                 <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                       <li class="nav-item active">
                           <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Quienes Somos</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link " href="#">Isapres</a>
                        </li>
                    </ul>
             </div>       
                </div>
        </nav>

    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="container">
         <div class="row">

            <div class="col-md-6">
           <div class="inner cover">
                        <h2 class="text-left">
                            Cotiza la isapre que mas te convenga totalmente 
                            <span class="badge badge-danger">GRATIS</span>
                        </h2>
                        <br>
                        <p class="lead text-left">
                            Somos una empresa que cuenta con contando directo con vendedores oficiales de isapres  de todas las sucursales del pais llega el formulario y  compara y adierete a la isapre que se ajuste a tus necesitades.
                            <hr>
                        </p>
                        <div class="row">
                            <div class="col-md-3 text-left">
                                <img src="<?php echo e(asset('images/f.png')); ?>" width="90" height="90">
                            </div>
                            <div class="col-md-9 text-left">
                                www.cotizaisaprechile.cl    <br>
                                Fono : 2471814<br>
                                Email :Consultas@cotizaisaprechile.cl
                            </div>
                        </div>
                      </div>
            </div>

            <div class="col-md-6">

           
                        <h2 class="text-left">LLena este formulario</h2><br>
                      <div class="grup-from">
                          
                          <form>
                             <input type="" name="" class="form-control" placeholder="Nombre Completo"><br>
                               
                                <!-- **************FIN ROW ************-->
                                <div class="row">
                                  <div class="col-md-6">
                                      <input type="" name="" class="form-control" placeholder="Telefono"><br>
                                  </div>
                                  <div class="col-md-6">
                                      <input type="" name="" class="form-control" placeholder="E-Mail"><br>
                                  </div> 

                                 </div>
                                 <!-- ************* FIN ROW **************-->
                                      <input type="" name="" class="form-control" placeholder="Ciudad y Comuna"><br>
                                      <textarea class="form-control" placeholder="" ></textarea>
                                <br>

                                <p class="lead text-left">
                                  <a href="#" class="btn btn-lg btn-outline-success">Solicitar Cotizacion</a>
                                </p>
                          </form>
                      </div>
                <!-- ************* FOOTER **************-->

                      <div class="mastfoot">
                        <div class="inner">
                          <p>www.cotizaisaprechile.cl</p>
                        </div>
                      </div>
                <!-- ************* FIN FOOTER **************-->

                    </div>
            </div> <!-- COL-MD-6 -->

          </div> <!-- FIN ROW-->

      </div>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

    </body>
</html>
