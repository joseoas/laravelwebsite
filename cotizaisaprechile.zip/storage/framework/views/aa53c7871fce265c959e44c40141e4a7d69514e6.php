<?php $__env->startSection('content'); ?>

   <div class="row">

              <div class="col-md-6">
             <div class="inner">
                          <h2 class="text-left">
                              Cotiza la isapre que mas te convenga totalmente 
                              <span class="badge badge-danger">GRATIS</span>
                          </h2>
                          <br>
                          <p class="lead text-left">
                              Somos una empresa que cuenta con contando directo con vendedores oficiales de isapres  de todas las sucursales del pais. llena el formulario y  compara y adierete a la isapre que se ajuste a tus necesitades.
                              <hr>
                          </p>
                          <div class="row">
                              <div class="col-md-2 text-left">
                                  <img src="<?php echo e(asset('images/f.png')); ?>" width="90" height="90">
                              </div>
                              <div class="col-md-10 text-left lead">
                                  www.cotizaisaprechile.cl    <br>
                                  Fono : 2471814<br>
                                  Email :Consultas@cotizaisaprechile.cl
                              </div>
                             
                          </div>
                        </div>
              </div>

          <div class="col-md-6">
            
                          <h2 class="text-left">LLena este formulario</h2><br>
                        <div class="grup-from">
                            


                            <form>
                               
                                       <div class="row">
                                
                                  <div class="form-group text-left">

                                    <div class="col-md-12">
                                       <p class="lead text-left" >Selecciona la isapre a cotizar</p>   
                                       <button class="btn btn-danger">Banmedica</button>
                                    </div>

                                    </div>

                                </div>                   
                                 <input type="" name="" class="form-control" placeholder="Nombre Completo"><br>
                                 
                                  <!-- **************FIN ROW ************-->
                                  <div class="row">
                                    <div class="col-md-6">
                                        <input type="" name="" class="form-control" placeholder="Telefono"><br>
                                    </div>

                                    <div class="col-md-6">
                                        <input type="" name="" class="form-control" placeholder="E-Mail"><br>
                                    </div> 

                                   </div>
                                   <!-- ************* FIN ROW **************-->
                                        <input type="" name="" class="form-control" placeholder="Ciudad y Comuna"><br>
                                        <textarea placeholder=" Cuentanos tu caso" class="form-control"  ></textarea>
                                  <br>

                                  <p class="lead text-left">
                                    <a href="#" class="btn btn-lg btn-outline-success"> <i class="fa fa-paper-plane" aria-hidden="true"> </i> Solicitar Cotizacion</a>
                                  </p>
                            </form>
                        </div>


                  <!-- ************* FOOTER **************-->

                  <!-- ************* FIN FOOTER **************-->

                      </div>
              </div> <!-- COL-MD-6 -->

            </div> <!-- FIN ROW-->

            <div class="container">
               <hr>

              <div class="jumbotron jumbotron-fluid">
              <div class="container">
                <h1 class="display-3">Quienes somos</h1>
                <p class="lead">Somos un grupo de ingenieros, que tiene por objetivo fundamental el facilitar a la gente cotizaciones de isapres de forma rápida sencilla y totalmente gratis, sin tener que acudir a una sucursal, ni esperar turnos de espera, nuestro objetico es ofrecer un servicio ágil e integral a todos nuestros visitantes, para lo cual nos encontramos abierto a sugerencias y aportes de terceros con la  única finalidad de entregar e ir mejorando nuestro servicio.</p>
              </div>
            </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>