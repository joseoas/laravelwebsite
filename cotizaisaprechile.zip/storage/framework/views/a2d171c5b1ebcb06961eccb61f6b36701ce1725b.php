<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header text-left"><i class="fa fa-university color_icon" aria-hidden="true"></i>
			<?php echo e((isset($data)) ? 'Editar Isapre' : 'Registrar  Isapre '); ?>

		</div>
			<form action="<?php echo e((isset($isapres)) ? route('isapres.update',$isapres->id) : route('isapres.add')); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="card-body text-left">
				<div class="form-group">
					 <label>Nombre isapre</label>
					<input type="text" class="form-control" name="name" value="<?php echo e((isset($isapres)) ? $isapres->name_isapre : ''); ?>">
				</div>
				<button class="btn  btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i> Guardar</button>
			</form>
		</div>

		<?php if($errors->any()): ?>
		    <div class=" text-left">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appbackend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>