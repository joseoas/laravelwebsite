<?php $__env->startSection('content'); ?>
			<div class="row">
				<div class="col-md-12">
					       <div class="text-left "><h4> <i class="fa fa-university color_icon" aria-hidden="true"></i>  Emails </h4></div><br>

							<div class="card ">
									<div class="card-header">
										<div class="row">
											<div class="col-md-10 text-left">
												 Cantidad total Emails : <div class="badge badge-danger"><?php echo e($count); ?></div>
											</div>
											<div class="col-md-2 text-right">
											
											</div>
										</div>
									</div>       
										<table class="table table-hover text-left ">
										  <thead >
										    <tr>
										      <th>#</th>
										      <th>Nombre</th>
										      <th>Email</th>
										      <th>Fono</th>
										      <th>Fecha</th>
										    </tr>
										  </thead>
										  <tbody>

										  	<?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    	    <tr>
												      <th scope="row"><?php echo e($key); ?></th>
												      <td><?php echo e($email->name_email); ?></td>
												      <td><?php echo e($email->name_email); ?></td>
												      <td><?php echo e($email->phone_emai); ?></td>												     <td><?php echo e($email->created_at); ?></td>

												      <td>
												      		<div class="row">
												      			<div class="col-md-3 text-lefet">
												      				<a href="#"	class="btn btn-info">
												      					<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar
												      				</a>
												      			</div>

												      			<div class="col-md-9 text-left">
												      				<form action="#" method="POST">
															      		<?php echo e(csrf_field()); ?>

															      		<?php echo e(method_field('DELETE')); ?>

															      		<button class="btn btn-danger" type="submit"><i class="fa fa-eraser" aria-hidden="true"></i> Eliminar</button>
												      				</form>
												      			</div>

												      		</div>
												

												      </td>
											      	</tr>
										    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										  </tbody>
									</table>
								</div> 

				</div><!--  FIN COL 7-->
				

			</div>

    <?php echo e($emails->links()); ?>

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appbackend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>