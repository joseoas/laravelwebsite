@extends('layouts.app')

@section('footer')

<div>
	asdasd636252222222222222222222222
</div>
@endsection